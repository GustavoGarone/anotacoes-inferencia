---
tags:
  - Inferência
---
# Na Teoria Estatística
Veja: [[Modelo Estatístico]] para definições dos modelos estatísticos paramétricos.
## Variável Populacional
Pela teoria estatística, população é o conjunto sob investigação de todos os potenciais elementos.

A *Variável Populacional* representa os valores numéricos de cada elemento da população:
$$X\sim f_{\theta,}\theta \in \Theta$$
em que $f_\theta$ é a [[Função Densidade de Probabilidade]] da [[Variável Aleatória|variável aleatória]] populacional. $\theta$ é o vetor de parâmetros (desconhecido) e $\Theta$ é o espaço paramétrico

## Amostra (Teórica)
É uma parte ou subconjunto da população.
### Amostra Aleatória
Dizemos que $(X_{1},\dots,X_{n})$ é uma amostra aleatória de X (v.a. populacional) se $X_{1},\dots,X_{n}$ forem independentes e identicamente distribuídas de acordo com a distribuição de $X$
Ou seja, 
$$\text{Independentes = }\begin{cases}X_{1}\sim f_{\theta,}\theta \in \Theta \\
. \\
. \\
. \\
X_{n} \sim f_{\theta}, \theta \in \Theta
\end{cases}$$
## Amostra (Observada)
É formada por valores numéricos após utilizar um procedimento de amostragem.
$$x_{1},\dots,x_{n}$$
em que $n$ é o tamanho amostral.

