---
tags:
  - Inferência
---
Tem como objetivo replicar artificialmente os dados de um [[Modelo Estatístico]] para estudar o comportamento de [[Estatísticas e Estimadores]] (ou qualquer procedimento estatístico)

# Método
1. Defina o modelo estatístico: “Seja $(X_{1},\dots,X_{n})$” [[População e amostra#Amostra Aleatória|a.a.]] de $X\sim f_{\theta,}\theta \in \Theta$.
2. Escolha $\theta_{0} \in \Theta$ e considere-o fixado daqui em diante.
3. Para $n$ fixado, gere ($x_{1}, x_{2},\dots,x_{n}$) a amostra observada de $X\sim f_{\theta_{0}}$
4. Armazene a amostra observada
5. Repita 3. e 4. $N=10000$ vezes
